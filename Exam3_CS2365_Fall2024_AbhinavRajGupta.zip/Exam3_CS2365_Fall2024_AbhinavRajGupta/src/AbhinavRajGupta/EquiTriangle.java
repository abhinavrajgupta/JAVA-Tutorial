package AbhinavRajGupta;

public final class EquiTriangle extends Triangle {
  private double x;
  private double y;
  private double z;
  x=y=z;
public EquiTriangle(double side1, double side2, double side3, double x, double y, double z) {
	super(side1, side2, side3);
	this.x = x;
	this.y = y;
	this.z = z;
}
public EquiTriangle() {
	super();
}
public double s(double x, double y, double z) {
	double s;
	return s=(3*x/2);
}
public double getArea(double x,double y, double z, double s) {
	return Math.sqrt(s*(s-x)*(s-y)*(s-z));	
}
public void printName() {
	System.out.println("Equilateral Triangle Class");
}

  
  
  
  
	
}

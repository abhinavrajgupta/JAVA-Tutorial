package AbhinavRajGupta;

public abstract class Shape {
protected String shape;

public void setShape(String shape) 
{}
public abstract void getShape();
}

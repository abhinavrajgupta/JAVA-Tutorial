package AbhinavRajGupta;

public interface Tr1_Gupta {
default void  printname() {
	System.out.println("Triangle Interface.");
}
}

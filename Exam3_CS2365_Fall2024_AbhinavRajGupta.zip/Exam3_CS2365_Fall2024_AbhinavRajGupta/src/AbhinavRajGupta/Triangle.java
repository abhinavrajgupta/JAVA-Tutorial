package AbhinavRajGupta;

public class Triangle extends Shape implements Triangle_Gupta{
	private double side1;
	private double side2;
	private double side3;
	
	public Triangle(double side1, double side2, double side3) {
		super();
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
	}

	public Triangle() {
		super();
	}
	
	public void printName()
	{
		
		System.out.println("Triangle Class");
	}

	@Override
	public void setShape(String shape) {
		// TODO Auto-generated method stub
		super.setShape(shape);
	}

	@Override
	public void getShape() {
		// TODO Auto-generated method stub
		
	}

	

	

	
	
	
	
	
	
	
	
	

}

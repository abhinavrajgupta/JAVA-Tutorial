package AbhinavRajGupta;

public class TriangleCL1 extends Triangle {

	public double s;
	
	
	public double a;
	public double b;
	public double c;
	public TriangleCL1() {
		super();
	}

	public TriangleCL1(double side1, double side2, double side3) {
		super(side1, side2, side3);
		
	}
	public double s(double a, double b, double c) {
		return s=((a+b+c)/2);
	}
	
	public double getArea(double side1,double side2, double side3, double s) {
		this.a=side1;
		this.b=side2;
		this.c=side3;
		return Math.sqrt(s*(s-a)*(s-b)*(s-c));	
		
	}

	
    
}
